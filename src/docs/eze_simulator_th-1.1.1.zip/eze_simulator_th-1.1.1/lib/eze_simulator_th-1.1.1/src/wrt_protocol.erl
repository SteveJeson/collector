%%%-------------------------------------------------------------------
%%% @author xugg
%%% @copyright (C) 2018, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 10. Jul 2018 4:22 PM
%%%-------------------------------------------------------------------
-module(wrt_protocol).
-author("xugg").

-define(MAX_REQUEST_ID, 4294967296).
-define(DEC(X), $0 + X div 10, $0 + X rem 10).

%% API
-export([request_id/1, request/4]).

request_id(RequestCounter) ->
  RequestCounter rem ?MAX_REQUEST_ID.

request(ReqId, Operation, RequestCounter, Mobile) ->
  case Operation of
    login ->
      LoginBin = get_login_bin(RequestCounter, Mobile),
      <<LoginBin/binary>>;
    device ->
      DeviceBin = get_device_bin(RequestCounter, Mobile),
      <<DeviceBin/binary>>;
%%    identify ->
%%      IdentifyBin = get_identify_bin(RequestCounter, Mobile),
%%      <<IdentifyBin/binary>>;
    ecu ->
      EcuBin = get_ecu_bin(RequestCounter, Mobile),
      <<EcuBin/binary>>;
    heartbeat ->
      HeartbeatBin = get_heartbeat_bin(RequestCounter, Mobile),
      <<HeartbeatBin/binary>>;
    position ->
      PositionBin = get_position_bin(RequestCounter, Mobile),
      <<PositionBin/binary>>;
    alarm ->
      PositionBin = get_alarm_bin(RequestCounter, Mobile),
      <<PositionBin/binary>>;
    _ -> <<>>
  end.

get_login_bin(_SeqNo, Mobile) ->
  %% TRV AP00  353456789012345 #
  Tag = "TRV",
  ProtocolNo = "AP00",
  %%Mobile = "353456789012345",
  Mobile1 = Mobile,  %%+ 16#100000000000000,
  Body = "",
  End = "#",
  get_bin(Tag, ProtocolNo, Mobile1, Body, null, End).

get_device_bin(_SeqNo, Mobile) ->
  %% TRV YP02 , 460023136470163 , 898602B1191550255484 #
  Tag = "TRV",
  ProtocolNo = "YP02",
  %%Mobile = "353456789012345",
  Body = ",460023136470163,898602B1191550255484",
  End = "#",
  get_bin(Tag, ProtocolNo, null, Body, null, End).

get_ecu_bin(_SeqNo, Mobile) ->
  %% TRV AP90 , 0105010000000105FE,010502131A00000EFE,01050300036EE883FE#
  Tag = "TRV",
  ProtocolNo = "AP90",
  %%Mobile = "353456789012345",
  Body = ",0105010000000105FE,010502131A00000EFE,01050300036EE883FE",
  End = "#",
  get_bin(Tag, ProtocolNo, null, Body, null, End).

get_heartbeat_bin(_SeqNo, Mobile) ->
  %% TRV YP07 , 06000908000200301010100201111 #
  Tag = "TRV",
  ProtocolNo = "YP07",
  %%Mobile = "0353413532150362",
  Body = ",060009080000200301010100201111",
  %%SeqNo = "0002",
  %%CheckSum = "2D06",
  End = "#",
  get_bin(Tag, ProtocolNo, null, Body, null, End).

get_position_bin(_SeqNo, Mobile) ->
  %% TRV YP03 080524 A 2232.9806N 11404.9355E 000.1 061830 323.8706000908000102000,460,0,9520,3671 #
  Tag = "TRV",
  ProtocolNo = "YP03",
  %%Mobile = "0353413532150362",
  Data = get_date(),
  Invalid = "A",
  Latitude = "2232.9806N",
  Longitude = "11404.9355E",
  Speed = "000.1",
  Time = get_time(),
  Rest = "323.8706000908000102000,460,0,9520,3671",
  Body = Data ++ Invalid ++ Latitude ++ Longitude ++ Speed ++ Time ++ Rest,
  %%SeqNo = "0002",
  %%CheckSum = "2D06",
  End = "#",
  get_bin(Tag, ProtocolNo, null, Body, null, End).

get_alarm_bin(_SeqNo, Mobile) ->
  %% TRV YP05 080524 A 2232.9806N 11404.9355E 000.1 061830 323.8706000908000102000,460,0,9520,3671,00,zh-cn,00#
  Tag = "TRV",
  ProtocolNo = "YP05",
  %%Mobile = "0353413532150362",
  Data = get_date(),
  Invalid = "A",
  Latitude = "2232.9806N",
  Longitude = "11404.9355E",
  Speed = "000.1",
  Time = get_time(),
  Rest = "323.8706000908000102000,460,0,9520,3671,00,zh-cn,00",
  Body = Data ++ Invalid ++ Latitude ++ Longitude ++ Speed ++ Time ++ Rest,
  %%SeqNo = "0002",
  %%CheckSum = "2D06",
  End = "#",
  get_bin(Tag, ProtocolNo, null, Body, null, End).

get_bin(Tag, ProtocolNo, Mobile, Body, SeqNo, End) ->
  TagBin = list_to_binary(Tag),
  EndBin = list_to_binary(End),

  Mobile1 = get_mobile_str(Mobile),
  SeqNo1 = get_seqno_str(SeqNo),
  H1 = ProtocolNo ++ Mobile1 ++ Body ++ SeqNo1, %%++ CheckSum ++ Tag,
  HH1 = list_to_binary(H1),

  <<TagBin/binary, HH1/binary, EndBin/binary>>.

get_mobile_str(null) ->
  "";
get_mobile_str(Mobile) ->
  trim(lists:flatten(io_lib:format("~15..0B~n", [Mobile + 100000000000000]))).
%%get_mobile_str(Mobile) ->
%%  case Mobile of
%%    "" -> "";
%%    _ ->
%%      MobileBin = <<Mobile:64>>,
%%      hex:bin_to_hexstr(MobileBin)
%%  end.

get_seqno_str(null) -> "";
get_seqno_str(SeqNo) ->
  integer_to_list(SeqNo + 1).

trim(A) ->
  re:replace(A, "(^\\s+)|(\\s+$)", "", [global,{return,list}]).

get_date() ->
  {{YY, MM, DD}, {_H, _M, _S}} = calendar:local_time(),
  [?DEC(YY rem 100), ?DEC(MM), ?DEC(DD)].

get_time() ->
  {{_YY, _MM, _DD}, {H, M, S}} = calendar:local_time(),
  [?DEC(H), ?DEC(M), ?DEC(S)].