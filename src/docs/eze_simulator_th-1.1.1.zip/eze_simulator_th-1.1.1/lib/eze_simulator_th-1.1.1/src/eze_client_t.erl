%%%-------------------------------------------------------------------
%%% @author xugg
%%% @copyright (C) 2017, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 23. Aug 2017 11:03
%%%-------------------------------------------------------------------
-module(eze_client_t).
-author("xugg").

-behavior(shackle_client).

-include("eze.hrl").

%% API
-export([
  start/1,
  identify/1,
  heartbeat/1,
  position/1,
  alarm/1,
  login/1,
  device/1,
  ecu/1
]).

-export([
  init/0,
  setup/2,
  handle_request/2,
  handle_data/2,
  terminate/1
]).

-record(state, {
  buffer =       <<>> :: binary(),
  request_counter = 0 :: non_neg_integer(),
  pool = null
}).

start(PoolName) ->
  start(?POOL_SIZE, PoolName).

%%-spec start(pos_integer()) ->
%%  ok | {error, shackle_not_started | pool_already_started}.
start(PoolSize, PoolName) ->
  {ok, IP} = server_ip(),
  {ok, Port} = server_port(),

%%  lager:info("===~p===: ~p (~p) ->  Getting app configuration, IP = ~p, Port = ~p, BlacklogSize = ~p ~n",
%%    [?MODULE, ?LINE, self(), IP, Port, ?BACKLOG_SIZE]),
  shackle_pool:start(PoolName, ?CLIENT_TCP, [
    {ip, IP},
    {port, Port},
    {reconnect, true},
    {socket_options, [
      binary,
      {packet, raw},
      {buffer, 1024000}
    ]}
  ], [
    {backlog_size, ?BACKLOG_SIZE},
    {pool_size, PoolSize}
  ]).

identify(Pool) ->
  shackle:call(Pool, {identify, Pool}, ?TIMEOUT).

heartbeat(Pool) ->
  shackle:call(Pool, {heartbeat, Pool}, ?TIMEOUT).

position(Pool) ->
  shackle:call(Pool, {position, Pool}, ?TIMEOUT).

alarm(Pool) ->
  shackle:call(Pool, {alarm, Pool}, ?TIMEOUT).

login(Pool) ->
  shackle:call(Pool, {login, Pool}, ?TIMEOUT).

device(Pool) ->
%%  lager:info("device == ~p~n", [Pool]),
  shackle:call(Pool, {device, Pool}, ?TIMEOUT).

ecu(Pool) ->
  shackle:call(Pool, {ecu, Pool}, ?TIMEOUT).

init() ->
  {ok, #state {}}.

setup(Socket, State) ->
%%  Reg = "7E0100002D9161227001100001002C012C373035303348543631314130303030303030303030303030300207000001010001D4C1423132333435A77E",
%%  RegBin = hex:hexstr_to_bin(Reg),
%%  RegRtn = "7e8100000e9161227001100001000100313233343536373839305a677e",
%%  RegRtnBin = hex:hexstr_to_bin(RegRtn),
%%  case gen_tcp:send(Socket, <<RegBin/binary>>) of
%%    ok ->
%%      case gen_tcp:recv(Socket, 0) of
%%        {ok, <<RegRtnBin/binary>>} ->
%%          {ok, State};
%%        {error, Reason} ->
%%          {error, Reason, State}
%%      end;
%%    {error, Reason} ->
%%      {error, Reason, State}
%%  end.
  {ok, State}.

handle_request({Operation, Pool}, #state {
  request_counter = RequestCounter
} = State) ->
  SeqNo = seq_no(RequestCounter),
  Mobile = list_to_integer(atom_to_list(Pool)),%%mobile(),

  {ok, Type} = application:get_env(eze_simulator_th, type),
  {RequestId, Data} = case Type of
    "808" ->
      ReqId = eze_protocol:request_id(RequestCounter),
      D = eze_protocol:request(ReqId, Operation, SeqNo, Mobile),
%%      lager:info("===~p===: ~p(~p) -> Sending (~p) : ~p ~n",
%%        [?MODULE, ?LINE, self(), Operation, hex:bin_to_hexstr(D)]),
      {ReqId, D};
    "gumi" ->
      ReqId = gumi_protocol:request_id(RequestCounter),
      D = gumi_protocol:request(ReqId, Operation, SeqNo, Mobile),
%%      lager:info("===~p===: ~p(~p) -> Sending (~p) : ~p ~n",
%%        [?MODULE, ?LINE, self(), Operation, hex:bin_to_hexstr(D)]),
      {ReqId, D};
    "wrt" ->
      ReqId = wrt_protocol:request_id(RequestCounter),
      D = wrt_protocol:request(ReqId, Operation, SeqNo, Mobile),
%%      lager:info("===~p===: ~p(~p) -> Sending (~p) : ~p ~n",
%%        [?MODULE, ?LINE, self(), Operation, binary_to_list(D)]),
      {ReqId, D};
    _ ->
      ""
  end,

  eze_counter:add(),
  {ok, RequestId, Data, State#state {
    request_counter = RequestCounter + 1,
    pool = Pool
  }}.

seq_no(Counter) ->
  mod(Counter, 16#FFFF).

mod(X,Y) when X > 0 -> X rem Y;
mod(X,Y) when X < 0 -> Y + X rem Y;
mod(0,_) -> 0.

handle_data(Data, #state {
  buffer = Buffer,
  pool = Pool
} = State) ->

%%  D = <<Buffer/binary, Data/binary>>, %%Receiving "TRVBP0020180711065112#"
%%  ReqId = null, %%wrt_protocol:request_id(RequestCounter),
%%  SeqNo = null,
%%  Mobile = null,
%%  Replies = wrt_protocol:request(ReqId, device, SeqNo, Mobile),
%%  %{Replies, Buffer2} = arithmetic_protocol:parse_replies(Data2, []),
%%%%
%%%%  Replies = <<>>,
%%  lager:info("===~p===: ~p(~p) -> Receiving ~p , replies ~p ~n",
%%    [?MODULE, ?LINE, self(), binary_to_list(D), binary_to_list(Replies)]),
%%%%  device(Pool),
%%%%  self() ! {device, Pool},
%%  Replies1 = [{Pool, Replies}],
  Replies1 = [],

  {ok, Replies1, State#state {
    buffer = Buffer
  }}.

-spec terminate(State :: term()) -> ok.
terminate(_State) -> ok.

server_ip() ->
  application:get_env(eze_simulator_th,ip).

server_port() ->
  application:get_env(eze_simulator_th,port).


