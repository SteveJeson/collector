%%%-------------------------------------------------------------------
%%% @author xugg
%%% @copyright (C) 2018, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 19. Jun 2018 4:22 PM
%%%-------------------------------------------------------------------
-module(gumi_protocol).
-author("xugg").

-include_lib("eunit/include/eunit.hrl").

-define(MAX_REQUEST_ID, 4294967296).
-define(DEC(X), $0 + X div 10, $0 + X rem 10).

%% API
-export([request_id/1, request/4]).

request_id(RequestCounter) ->
  RequestCounter rem ?MAX_REQUEST_ID.

request(ReqId, Operation, RequestCounter, Mobile) ->
  case Operation of
    login ->
      LoginBin = get_login_bin(RequestCounter, Mobile),
      <<LoginBin/binary>>;
%%    identify ->
%%      IdentifyBin = get_identify_bin(RequestCounter, Mobile),
%%      <<IdentifyBin/binary>>;
    heartbeat ->
      HeartbeatBin = get_heartbeat_bin(RequestCounter, Mobile),
      <<HeartbeatBin/binary>>;
    position ->
      PositionBin = get_position_bin(RequestCounter, Mobile),
      <<PositionBin/binary>>;
    alarm ->
      PositionBin = get_alarm_bin(RequestCounter, Mobile),
      <<PositionBin/binary>>;
    _ -> <<>>
  end.

get_login_bin(SeqNo, Mobile) ->
  %% 7878 0D 01 0353413532150362 0002 2D06 0D0A
  Tag = "7878",
  Len = "0D",
  ProtocolNo = "01",
  %%Mobile = "0353413532150362",
  Mobile1 = Mobile + 16#0100000000000000,
  Body = "",
  %%SeqNo = "0002",
  %%CheckSum = "2D06",
  End = "0D0A",
  get_bin(Tag, Len, ProtocolNo, Mobile1, Body, SeqNo, End).

get_heartbeat_bin(SeqNo, Mobile) ->
  %% 7878 0D 01 0353413532150362 0002 2D06 0D0A
  Tag = "7878",
  Len = "08",
  ProtocolNo = "13",
  %%Mobile = "0353413532150362",
  Mobile1 = "",
  Body = "0000000000",
  %%SeqNo = "0002",
  %%CheckSum = "2D06",
  End = "0D0A",
  get_bin(Tag, Len, ProtocolNo, Mobile1, Body, SeqNo, End).

get_position_bin(SeqNo, Mobile) ->
  %% 7878 0D 01 0353413532150362 0002 2D06 0D0A
  Tag = "7878",
  Len = "20",
  ProtocolNo = "22",
  %%Mobile = "0353413532150362",
  Mobile1 = "",
  DataTime = date_time(),
  GPS = "000000000000000000000000",
  LBS = "0000000000000000",
  ACC = "00",
  UploadMode = "00",
  GPSPost = "00",
  Body = DataTime ++ GPS ++ LBS ++ ACC ++ UploadMode ++ GPSPost,
  %%SeqNo = "0002",
  %%CheckSum = "2D06",
  End = "0D0A",
  get_bin(Tag, Len, ProtocolNo, Mobile1, Body, SeqNo, End).

get_alarm_bin(SeqNo, Mobile) ->
  %% 7878 0D 01 0353413532150362 0002 2D06 0D0A
  Tag = "7878",
  Len = "23",
  ProtocolNo = "26",
  %%Mobile = "0353413532150362",
  Mobile1 = "",
  DataTime = date_time(),
  GPS = "000000000000000000000000",
  LBS = "080000000000000000",
  State = "0000000000",
  Body = DataTime ++ GPS ++ LBS ++ State,
  %%SeqNo = "0002",
  %%CheckSum = "2D06",
  End = "0D0A",
  get_bin(Tag, Len, ProtocolNo, Mobile1, Body, SeqNo, End).

get_bin(Tag, Len, ProtocolNo, Mobile, Body, SeqNo, End) ->
  TagBin = hex:hexstr_to_bin(Tag),
  LenBin = hex:hexstr_to_bin(Len),
  ProtocolNoBin = hex:hexstr_to_bin(ProtocolNo),
  Mobile1 = get_mobile_str(Mobile),
  SeqNoBin = <<(SeqNo+1):16>>,
  SeqNo1 = hex:bin_to_hexstr(SeqNoBin),
  H1 = Len ++ ProtocolNo ++ Mobile1 ++ Body ++ SeqNo1, %%++ CheckSum ++ Tag,
  HH1 = hex:hexstr_to_bin(H1),
  CheckSum1 = checksum(HH1),
  CheckSumBin = binary:encode_unsigned(CheckSum1),
  CHex = hex:bin_to_hexstr(CheckSumBin),
  H2 = H1 ++ CHex,
  HH2 = hex:hexstr_to_bin(H2),
  EndBin = hex:hexstr_to_bin(End),
  %%ChexBin =hex:hexstr_to_bin(CHex).
  %%<<CheckSumBin:8>>.
  %%CheckSumBin.
%%  HH3 = encode_7e_7d(HH2),
  <<TagBin/binary, HH2/binary, EndBin/binary>>.

get_mobile_str(Mobile) ->
  case Mobile of
    "" -> "";
    _ ->
      MobileBin = <<Mobile:64>>,
      hex:bin_to_hexstr(MobileBin)
  end.

%%checksum(Bin) ->
%%  checksum(Bin, 0).
%%checksum(<<>>, ACC) ->
%%  ACC;
%%checksum(<<X:8, Rest/binary>>, ACC) ->
%%  R = ACC bxor X,
%%%%  lager:info("===~p===: ~p(~p) -> ACC:~p BXOR X:~p = R ~n",
%%%%    [?MODULE, ?LINE, self(), ACC, X, R]),
%%  checksum(Rest, R).

checksum(Bin) ->
  crc16:calc(Bin).

checksum_test() ->
  H1 = "0D0103534135321503620002",
  HH1 = hex:hexstr_to_bin(H1),
  HH2 = hex:hexstr_to_bin("2D06"),
  C = checksum(HH1),
  ?assertEqual(<<C:16>>, HH2).

date_time() ->
  {{YY, MM, DD}, {H, M, S}} = calendar:local_time(),
  [?DEC(YY rem 100), ?DEC(MM), ?DEC(DD),
    ?DEC(H), ?DEC(M), ?DEC(S)].
